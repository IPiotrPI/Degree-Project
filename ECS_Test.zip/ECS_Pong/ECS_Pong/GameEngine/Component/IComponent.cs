﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ECS_Pong.GameEngine.Component
{
    interface IComponent
    {
    }
}
