﻿namespace PongEx1
{
    interface IInputManager
    {
        void Update();
    }
}
