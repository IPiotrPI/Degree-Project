﻿namespace PongEx1
{
    class InputManager
    {
        public void Update() { }
    }
}
