﻿namespace PongEx1
{
    public interface ICollisionManager
    {
        void Update();

    }
}
