﻿namespace PongEx1
{
    interface IBall
    {
    }
}
