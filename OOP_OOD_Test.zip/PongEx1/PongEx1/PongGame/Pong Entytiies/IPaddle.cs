﻿namespace PongEx1
{
    interface IPaddle
    {

    }
}
